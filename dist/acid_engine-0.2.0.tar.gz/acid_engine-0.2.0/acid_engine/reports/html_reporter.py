import os

class HTMLReporter:
    """Генерирует самодостаточный HTML-отчёт о валидации."""

    def __init__(self, project_name, project_version):
        self.project_name = project_name
        self.project_version = project_version
        self.sections = []

    def add_summary(self, total_pass, total_fail, total_skipped):
        self.sections.append(f"""
        <div class="summary">
            <h2>Overall Statistics</h2>
            <div class="stats">
                <div class="stat pass">{total_pass}<span>PASS</span></div>
                <div class="stat fail">{total_fail}<span>FAIL</span></div>
                <div class="stat skipped">{total_skipped}<span>SKIPPED</span></div>
            </div>
        </div>
        """)

    def add_top_violations(self, violations):
        rows = ""
        for msg, count in violations:
            rows += f"<tr><td>{msg}</td><td>{count}</td></tr>"
        self.sections.append(f"""
        <div class="violations">
            <h2>Top Violations</h2>
            <table>
                <tr><th>Violation</th><th>Count</th></tr>
                {rows}
            </table>
        </div>
        """)

    def add_error_examples(self, errors):
        examples = ""
        for err in errors[:5]:
            examples += f"""
            <div class="error-card">
                <div class="error-row"><strong>Row:</strong> {err.get('row', {})}</div>
                <div class="error-reason"><strong>Reason:</strong> {err.get('reason', 'N/A')}</div>
                <div class="error-expected"><strong>Expected:</strong> {err.get('expected', 'N/A')}</div>
                <div class="error-received"><strong>Received:</strong> {err.get('received', 'N/A')}</div>
            </div>
            """
        self.sections.append(f"""
        <div class="errors">
            <h2>Error Examples</h2>
            {examples}
        </div>
        """)

    def render(self):
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AcidEngine Report – {self.project_name} v{self.project_version}</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f7fa; margin: 0; padding: 20px; }}
        .container {{ max-width: 900px; margin: 0 auto; background: white; border-radius: 12px; box-shadow: 0 4px 16px rgba(0,0,0,0.08); padding: 30px; }}
        h1 {{ color: #1a1a2e; margin-bottom: 8px; }}
        h2 {{ color: #333; border-bottom: 1px solid #eee; padding-bottom: 6px; margin-top: 32px; }}
        .version {{ color: #666; font-size: 14px; }}
        .stats {{ display: flex; gap: 20px; margin-top: 16px; }}
        .stat {{ flex: 1; padding: 20px; border-radius: 10px; text-align: center; font-size: 28px; font-weight: bold; color: white; }}
        .stat span {{ display: block; font-size: 14px; font-weight: normal; margin-top: 6px; opacity: 0.9; }}
        .pass {{ background: #2ecc71; }}
        .fail {{ background: #e74c3c; }}
        .skipped {{ background: #f39c12; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 12px; }}
        th, td {{ padding: 10px; text-align: left; border-bottom: 1px solid #eee; }}
        th {{ background: #f8f9fa; font-weight: 600; }}
        .error-card {{ background: #fff5f5; border-left: 4px solid #e74c3c; padding: 12px; margin: 12px 0; border-radius: 6px; }}
        .error-card div {{ margin: 4px 0; }}
        .error-reason {{ color: #c0392b; }}
        .error-expected {{ color: #27ae60; }}
        .error-received {{ color: #e67e22; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>AcidEngine Execution Report</h1>
        <div class="version">Project: {self.project_name} v{self.project_version}</div>
        {''.join(self.sections)}
    </div>
</body>
</html>"""