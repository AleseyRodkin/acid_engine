from lark import Lark, Tree, Token
import os

def parse_contract(file_path):
    grammar_path = os.path.join(os.path.dirname(__file__), "grammar.lark")
    with open(grammar_path, "r") as f:
        grammar = f.read()
    parser = Lark(grammar, parser='lalr')
    with open(file_path, "r") as f:
        tree = parser.parse(f.read())
    return transform_tree(tree)

def transform_tree(tree):
    if isinstance(tree, Tree):
        if tree.data == "start":
            return {
                "spec_version": transform_tree(tree.children[0]),
                "project": transform_tree(tree.children[1]),
                "input": transform_tree(tree.children[2]),
                "output": transform_tree(tree.children[3]),
                "implementation": transform_tree(tree.children[4])
            }
        elif tree.data == "spec_version":
            return str(tree.children[0])[1:-1]
        elif tree.data == "project_section":
            return {"name": str(tree.children[0])[1:-1], "version": str(tree.children[1])[1:-1]}
        elif tree.data in ("input_section", "output_section", "implementation_section"):
            return [transform_tree(child) for child in tree.children]
        elif tree.data == "source":
            return {"name": str(tree.children[0])}
        elif tree.data == "stage":
            result = {
                "name": str(tree.children[0]),
                "input": transform_tree(tree.children[1]),
                "output": transform_tree(tree.children[2]),
                "use": None,
                "schema": [],
                "require": [],
                "join": [],
                "enrich": [],
                "derive": []
            }
            remaining = list(tree.children[3:])
            while remaining:
                child = remaining.pop(0)
                transformed = transform_tree(child)
                if isinstance(child, Tree):
                    if child.data == "use_block":
                        result["use"] = transformed
                    elif child.data == "schema_block":
                        result["schema"] = transformed
                    elif child.data == "require_block":
                        result["require"] = transformed
                    elif child.data == "join_block":
                        result["join"].append(transformed)
                    elif child.data == "enrich_block":
                        result["enrich"].append(transformed)
                    elif child.data == "derive_block":
                        result["derive"] = transformed
            return result
        elif tree.data == "input_block":
            return str(tree.children[0])
        elif tree.data == "output_block":
            return str(tree.children[0])
        elif tree.data == "use_block":
            return str(tree.children[1])
        elif tree.data == "join_block":
            return {
                "target": str(tree.children[1]),
                "source": str(tree.children[3]),
                "on": str(tree.children[5])
            }
        elif tree.data == "enrich_block":
            return {
                "field": str(tree.children[0]),
                "source": str(tree.children[2]),
                "source_field": str(tree.children[4])
            }
        elif tree.data == "schema_block":
            return [transform_tree(child) for child in tree.children]
        elif tree.data == "require_block":
            return [transform_tree(child) for child in tree.children]
        elif tree.data == "derive_block":
            # возвращаем список derive_rule
            return [transform_tree(child) for child in tree.children]
        elif tree.data == "derive_rule":
            # CNAME "=" CNAME DERIVE_OP CNAME
            return {
                "target": str(tree.children[0]),
                "left": str(tree.children[1]),
                "op": str(tree.children[2]),
                "right": str(tree.children[3])
            }
        elif tree.data == "is_integer":
            return {"field": str(tree.children[0]), "operator": "is", "value": "integer"}
        elif tree.data == "is_float":
            return {"field": str(tree.children[0]), "operator": "is", "value": "float"}
        elif tree.data == "is_string":
            return {"field": str(tree.children[0]), "operator": "is", "value": "string"}
        elif tree.data == "compare_rule":
            op = str(tree.children[1])
            return {"field": str(tree.children[0]), "operator": op, "value": float(tree.children[2])}
        elif tree.data == "between_rule":
            return {"field": str(tree.children[0]), "operator": "between", "value": [int(tree.children[1]), int(tree.children[2])]}
        else:
            raise ValueError(f"Unknown tree data: {tree.data}")
    elif isinstance(tree, Token):
        return str(tree)
    return tree